# Youtube Comments Analyzer

![image](https://user-images.githubusercontent.com/45345120/80210577-f4372280-866e-11ea-8b1e-b3987ab82e96.jpg)
![image](https://user-images.githubusercontent.com/45345120/80210580-f4cfb900-866e-11ea-9ad1-2a7a85ca32d4.jpg)
![image](https://user-images.githubusercontent.com/45345120/80210684-2052a380-866f-11ea-8537-82a57e23c822.jpg)
![image](https://user-images.githubusercontent.com/45345120/80210137-30b64e80-866e-11ea-806e-1d119cdb0902.jpg)
![image](https://user-images.githubusercontent.com/45345120/80210139-31e77b80-866e-11ea-9478-f8a18d4f3b6f.jpg)
![image](https://user-images.githubusercontent.com/45345120/80209960-e59c3b80-866d-11ea-9316-a69f6eb5f603.jpg)
![image](https://user-images.githubusercontent.com/45345120/80209968-e765ff00-866d-11ea-9691-e27d2791771d.jpg)
![image](https://user-images.githubusercontent.com/45345120/80209970-e7fe9580-866d-11ea-9181-0f0a3230e3cb.jpg)
![image](https://user-images.githubusercontent.com/45345120/80209972-e8972c00-866d-11ea-9826-eca83c270640.jpg)
![image](https://user-images.githubusercontent.com/45345120/80209981-ea60ef80-866d-11ea-8092-35a0c46af798.jpg)
